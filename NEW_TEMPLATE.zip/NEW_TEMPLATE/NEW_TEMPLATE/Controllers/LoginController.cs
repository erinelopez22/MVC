﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using globalSettings;
using loginDAL;


namespace NEW_TEMPLATE.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login(string Username, string Password)
        {
            
            GlobalSettings gs = new GlobalSettings();
            LoginDAL DalLogin = new LoginDAL();
            try
            {
                
                ModelState.Clear();
                DataTable dt = DalLogin.GetEmployees( new SqlParameter("@UserName", Username),
                                new SqlParameter("@Password", Password),
                                new SqlParameter("@ProgramName", gs.Appname1),
                                new SqlParameter("@IP", gs.GetLocalIPAddress()));

                if (dt.Rows.Count > 0)
                {
                    return Json(new { success = true, message = "Login Successful.", JsonRequestBehavior = JsonRequestBehavior.AllowGet });
                }
               
                //HttpCookie cookie = new HttpCookie("User");
                //cookie.Values.Add("UserID", result.UserInfo[0].UserID);
                //cookie.Values.Add("Username", Username);
                //cookie.Values.Add("EmpName", result.UserInfo[0].Empname);
                //cookie.Values.Add("UserType", result.UserInfo[0].UserType);
                //cookie.Values.Add("Add", result.UserInfo[0].Add);
                //cookie.Values.Add("Edit", result.UserInfo[0].Edit);
                //cookie.Values.Add("Delete", result.UserInfo[0].Delete);
                //cookie.Values.Add("View", result.UserInfo[0].View);
                //cookie.Values.Add("Print", result.UserInfo[0].Print);
                //cookie.Values.Add("Import", result.UserInfo[0].Import);
                //cookie.Values.Add("Export", result.UserInfo[0].Export);
                //cookie.Values.Add("Post", result.UserInfo[0].Post);
                //cookie.Values.Add("Unpost", result.UserInfo[0].Unpost);
                //cookie.Values.Add("Approve", result.UserInfo[0].Approve);
                //cookie.Values.Add("ViewNewVer", result.UserInfo[0].ViewNewVer);
                //cookie.Values.Add("IPAddress", gs.IP);

                //cookie.HttpOnly = true;
                //Response.Cookies.Add(cookie);
                //FormsAuthentication.SetAuthCookie(result.UserInfo[0].UserName, false);

                return Json(new { success = true, message = "Login Successful.", link = @Url.Action("Index", "Home"), JsonRequestBehavior = JsonRequestBehavior.AllowGet });
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(410, ex.Message);
            }





        }
        //public ActionResult UserModule()
        //{

        //    LoginDAL dal = new LoginDAL();
        //    ModelState.Clear();
        //    try
        //    {
        //        var result = dal.UserModule(@Request.Cookies["User"]["Username"]);
        //        return Json(JsonConvert.SerializeObject(result), JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        return new HttpStatusCodeResult(410, ex.Message);
        //    }


        //}
    }
}